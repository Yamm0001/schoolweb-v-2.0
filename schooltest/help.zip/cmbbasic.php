<?php include('headerd.php') ?>
<section class="sub-headercmb">
      <nav>
        <a href="home.html"><img src="Images/logo-bl.png" alt="" /></a>
        <div class="nav-links" id="navLinks">
            
<i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="about.php">ABOUT</a></li>
            <li><a href="courses.php">COURSES</a></li>
            <li><a href="blog.php">CHAT BOT</a></li>
            <li><a href="contact.php">CONTACT</a></li>
          </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
      <h1>Computer Basic Detail</h1>
    </section>

    <section style="width: 1000px; margin-left: 320px;" class="blog">

<div class="box">
    <div class="image">
        <img src="./Images/computer-basic.png" alt="">
    </div>
        <h3>Computer Basic Course</h3>
        <p style="font-size: 15px;"><b>ကွန်ပျူတာအခြေခံ ဘာသာရပ်တွင် သင်ယူရမည့် အကြောင်းအရာများ။

            ✓ ကွန်ပျူတာ စနစ်အလုပ်လုပ်ပုံ
            
            / ကွန်ပျူတာ ပစ္စည်းများအကြောင်း
            
            ✓ ကွန်ပျူတာ ဆော့ဝဲလ်များအကြောင်း
            
            ✓ ကွန်ပျူတာ ကီးဘုတ်လက်ကွက်များ
            
            ✓ကွန်ပျူတာ Typing လေ့ကျင့်ခြင်း
            
            v အခြေခံ စာစီစာရိုက် (Word)
            
            ✓ အခြေခံ စာရင်းဇယားများ (Excel)
            
            V အင်တာနက်ဆိုင်ရာ သင်ခန်းစာများ
            
            ✓CV Form ရေးသားနည်းများ
            
            Online စာမေးပွဲ ဖြေဆိုလေ့ကျင့်ခြင်း
            
            ⚠️Onlineပုံစံဖြစ်တဲ့အတွက်computerလေး
            တော့လိုမယ်နော်။⚠️
            
            တက်သင့်သော သူများ။
            
            အထက်တန်းကျောင်းသူ/သားများ
            
            ✓ ကွန်ပျူတာ မသုံးဖူးသေးသော သူများ
            
            Office Staff အလုပ်လျှောက်ထားမည့်သူများ
            
            / ကွန်ပျူတာ စိတ်ဝင်စားသူများ
            
            / ကွန်ပျူတာကို ပြန်လည်၍ လေ့ကျင့်လိုသူများ
            
            / လုပ်ငန်းခွင်ဝင်မည့်သူများ
            
            ကွန်ပျူတာအခြေခံသင်တန်းများ ကို အသက် မကန့်သတ်ထားပဲ မည်သူမဆိုတက်ရောက် သင်ကြားနိုင်ပါသည်။
            
            ပညာအရေးချင်း သပ်မှတ်ထားခြင်းမရှိပဲမည်သူမဆိုလာရောက်တက်လိုရနိုင်ပါသည်။
            
            နောက်ပီးကွန်ပျူတာသင်တန်းတက်လိုမကြိုက်ဘူးအဆင်မပြေဘူးဆိုရင်လဲ၃ရက်အတွင်းပိုက်ဆံပြန်ထုပ်ပေးမှာပါနော်။
            
            သင်တန်းကြေးလေးကတော့8000လေးထဲပါနော်🤗
            
            Google Meet လေးနဲ့သင်မှာဖြစ်တဲ့အတွက် Broswer or Google Meet app လေးကမရှိမဖြစ်လိုတယ်နော်🫶
            
            အကြောင်းအရာပြည့်ပြည်စုံစုံသိလိုပါက <a href="https://www.facebook.com/profile.php?id=61553247316466&mibextid=ZbWKwL" target="_blank"> page messenger </a> ကိုလာရောက်ဖိုလဲဖိတ်ခေါ်ချင်ပါတယ်နော်💗🫶💗</b><br/><br/>                 
            <a href="From.html" class="btn-sucess" style="margin-right: 15px;">Add Now</a>
            <a href="blog.html" class="btn-red">Cancel</a>
    </div>
</div>
</section>