<section class="footer">
      <h1>About Us</h1>
      <div class="footer-intro">
        <p>
          "This class is for beginners who doesn't know how to use computer.In this class. 
          <br />our courses are computer basic, programming basic and website basic."
        </p>
      </div>
      <div class="icons" style="margin: 25px;">
        <a href="https://www.facebook.com/profile.php?id=100094296491449" style="margin-right: 20px;" ><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://twitter.com/RANIT_MANIK" style="margin-right: 20px;"><i class="fa-brands fa-twitter"></i></a>
        <a href="https://www.instagram.com/ranit_manik_/" style="margin-right: 20px;"><i class="fa-brands fa-instagram"></i></a>
        <a href="https://www.linkedin.com/in/ranit-manik/"><i class="fa-brands fa-github"></i></a>
      </div>
      <p>Developed By <i class="fad fa-brackets-curly"></i> Phone Htut Khaung &#38; Aung Myat Thu</p>
      <p style="margin-bottom: 0;">Copyright <i class="fa-duotone fa-copyright"></i> TLTC 2024 All Right Reseved.</p>
      <p class="fw-lighter text-md-end mt-2 me-3"><i class="fa-duotone fa-v"></i> 2.0</p>
    </section>