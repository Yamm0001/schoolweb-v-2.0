</div>
<p class="text-lowercase">Lowercased text.</p>
</body>
</html>