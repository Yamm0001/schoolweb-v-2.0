# PHP-Admin-Panel
This is an PHP-based admin panel with clean and elegant design. MVC File Structure is also added. Every authentication files including Login, Logout, Change Password, Forgot Password &amp; Reset Password modules are added with controllers. Admin Login is created as well and database file is included alon with the connection file. Sessions are also taken care off. Just change the database name and you're good to go.



**DEFAULT LOGIN CREDENTIALS**      
Username: **admin@google.com**      
Password: **Pt123456789**         







**Dashboard UI**     

![dashboard_ui](https://user-images.githubusercontent.com/43801497/64510112-f2e30080-d2fe-11e9-8c79-d4e8eee540dd.jpg)

